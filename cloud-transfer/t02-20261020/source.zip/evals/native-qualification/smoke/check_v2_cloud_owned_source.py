#!/usr/bin/env python3
"""No-Docker cloud owned pin/origin and failure-teardown checks."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[3]
RUNNER = ROOT / 'evals/native-qualification/smoke/opencode_v2_managed_owned.py'
MANIFEST = ROOT / 'evals/native-qualification/t02-cloud-transfer-20261020/SOURCE-MANIFEST.json'
RELAY = 'experiments/native-network-preflight/tcp-relay-host-override/cloud-linux-amd64-20261020a/tcp-relay-linux-amd64'
RELAY_SHA = '33ef7484c2a2415915af399689e91e9efee8000b2c685a6b2b72eb4eddedf895'


def load(path):
    spec = importlib.util.spec_from_file_location('cloud_owned_runner_check', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(staged, output, marker, corrupt_copy=False):
    runner = staged / RUNNER.relative_to(ROOT)
    args = ['--output', str(output), '--cloud-platform', 'linux/amd64',
            '--cloud-image-id', 'sha256:' + 'a' * 64,
            '--cloud-relay', str(staged / RELAY), '--cloud-relay-sha256', RELAY_SHA,
            '--cloud-external-subnet', '172.28.224.0/24',
            '--cloud-listen-address', '172.28.224.1',
            '--cloud-relay-peer', '172.28.224.10',
            '--cloud-upstream-route', 'HTTPS_PROXY']
    env = os.environ.copy()
    env['HTTPS_PROXY'] = 'http://127.0.0.1:3128'
    env['T02_DOCKER_MARKER'] = str(marker)
    env['PATH'] = str(staged / 'fake-bin') + os.pathsep + env.get('PATH', '')
    if corrupt_copy:
        code = '''
import importlib.util, pathlib, sys
path = pathlib.Path(sys.argv[1]); spec = importlib.util.spec_from_file_location('candidate', path)
candidate = importlib.util.module_from_spec(spec); spec.loader.exec_module(candidate)
original = candidate.shutil.copy2
def corrupt(source, destination, *args, **kwargs):
    result = original(source, destination, *args, **kwargs)
    if pathlib.Path(source) == candidate.CONFIG and 'source' in pathlib.Path(destination).parts:
        pathlib.Path(destination).write_bytes(pathlib.Path(destination).read_bytes() + b' ')
    return result
candidate.shutil.copy2 = corrupt
sys.argv = [str(path), *sys.argv[2:]]
raise SystemExit(candidate.main())
'''
        command = [sys.executable, '-c', code, str(runner), *args]
    else:
        command = [sys.executable, str(runner), *args]
    return subprocess.run(command, env=env, capture_output=True, text=True, timeout=15)


def check_teardown(module, root):
    original = module.cleanup_owned
    try:
        for mode in ('pass', 'close_error', 'uncertain'):
            work = root / ('temporary-' + mode)
            work.mkdir(mode=0o700)
            (work / 'capability').write_text('test-only')
            calls = []

            class Native:
                def close(self):
                    assert work.exists()
                    calls.append('close')
                    if mode == 'close_error':
                        raise RuntimeError('synthetic_stop_failure')
                    return {'status': 'stopped'}

            def cleanup(resources, nonce, docker):
                assert work.exists()
                calls.append('cleanup')
                return [{'kind': 'container', 'id': 'owned', 'absent': mode != 'uncertain'}]

            module.cleanup_owned = cleanup
            result = module.finish_owned(Native(), [('container', 'owned')], 'nonce', None, work)
            assert calls == ['close', 'cleanup'], (mode, calls)
            assert result['cleanup_complete'] is (mode != 'uncertain')
            assert result['temporary_secret_files_removed'] is (mode != 'uncertain')
            assert work.exists() is (mode == 'uncertain')
            if mode == 'close_error':
                assert result['native_stop_error']['code'] == 'synthetic_stop_failure'
            if mode == 'uncertain':
                assert result['temporary_workspace_unresolved'] == str(work)
                shutil.rmtree(work)
    finally:
        module.cleanup_owned = original


def main():
    module = load(RUNNER)
    with tempfile.TemporaryDirectory(prefix='t02-cloud-owned-source-') as directory:
        temp = Path(directory)
        staged = (temp / 'repo').resolve()
        for item in json.loads(MANIFEST.read_text())['files']:
            source = ROOT / item['path']
            destination = staged / item['path']
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
        fake = staged / 'fake-bin/docker'
        fake.parent.mkdir()
        fake.write_text('#!/bin/sh\nprintf called >> "$T02_DOCKER_MARKER"\nexit 99\n')
        fake.chmod(0o700)
        staged_module = load(staged / RUNNER.relative_to(ROOT))
        assert len(staged_module.CLOUD_OWNED_INPUT_SHA) == 7
        marker = temp / 'docker-called'
        for index, path in enumerate(staged_module.CLOUD_OWNED_INPUT_SHA):
            source = staged / path.relative_to(staged_module.ROOT)
            original = source.read_bytes()
            source.write_bytes(original + b' ')
            output = temp / ('mutated-' + str(index))
            result = run(staged, output, marker)
            assert result.returncode != 0 and 'cloud_owned_input_pin_mismatch' in result.stderr
            assert not output.exists() and not marker.exists(), path
            source.write_bytes(original)
        output = temp / 'archive-mutated'
        result = run(staged, output, marker, corrupt_copy=True)
        assert result.returncode != 0 and not marker.exists()
        report = json.loads((output / 'result.json').read_text())
        assert {'name': 'archived cloud owned inputs match fixed reviewed pins', 'pass': False} in report['checks']
        assert report['status'] == 'fail'
        output = temp / 'archive-unchanged'
        result = run(staged, output, marker)
        assert result.returncode != 0 and marker.exists()
        report = json.loads((output / 'result.json').read_text())
        assert {'name': 'archived cloud owned inputs match fixed reviewed pins', 'pass': True} in report['checks']
        assert {'name': 'cloud owned mounts and fixture sources select archive', 'pass': True} in report['checks']
        check_teardown(module, temp)
    print('PASS: 7 pre-output mutations, archived-copy rejection, archive origins, 3 teardown orders; no real Docker/provider/CI')


if __name__ == '__main__':
    main()
